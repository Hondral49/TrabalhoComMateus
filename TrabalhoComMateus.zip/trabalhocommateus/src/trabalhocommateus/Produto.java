package trabalhocommateus;

public class Produto {

	private Integer idProduto;
	private String descricao;
	private Integer quantidade;
	private String marca;
	private Double preco;

	public Produto(Integer idProduto, String descricao, Integer quantidade, String marca, Double preco) {
		super();
		this.idProduto = idProduto;
		this.descricao = descricao;
		this.quantidade = quantidade;
		this.marca = marca;
		this.preco = preco;
	}

	public Integer getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(Integer idProduto) {
		this.idProduto = idProduto;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}
}