package trabalhocommateus;

import exceptions.SerasaException;
import exceptions.ValorNegativoException;
import exceptions.ViaDoClienteException;

public class Venda {

	private Integer Id_venda;
	private double preco_total;
	private double desconto;
	
	public Venda(Integer Id_venda, double preco_total, double desconto) {
		super();
		this.Id_venda = Id_venda;
		this.preco_total = preco_total;
		this.desconto = desconto;
	}

	public Integer getId_venda() {
		return Id_venda;
	}

	public void setId_venda(Integer Id_venda) {
		this.Id_venda = Id_venda;
	}

	public double getpreco_total() {
		return preco_total;
	}

	public void setpreco_total(double preco_total) {
		this.preco_total = preco_total;		
	}

	public double getdesconto () {
		return desconto;
	}
	
	public void setdesconto(double desconto) {
		this.desconto = desconto;
	}
	
	public Double getValorTotal() {
		return preco_total;
	}

	public void calcularValorTotal() {
		if (desconto < 0) {
			throw new ValorNegativoException("O item n�o tem desconto, o cliente pagar� o valor bruto!! ");
		}
		if (preco_total < 0) {
			throw new ValorNegativoException("O sub total esta negativo");
		}
		this.preco_total = this.preco_total - this.desconto;
	}
	
	public String gerarViaCliente() {
		Boolean gerarErro = true;
		if (gerarErro) {
			throw new ViaDoClienteException("Ocorreu um erro ao gerar a via do cliente");
		}
		return "A via do cliente foi gerada";
	}
	
	public void VerificarSerasa() {
		Boolean gerarErro = true;
		if (gerarErro) {
			throw new SerasaException("O nome do cliente consta no serasa.");
		}
	}
	
}