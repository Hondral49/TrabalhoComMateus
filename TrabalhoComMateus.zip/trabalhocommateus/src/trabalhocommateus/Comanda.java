package trabalhocommateus;

import java.util.ArrayList;
import java.util.List;
import exceptions.ValorIlegalException;
import exceptions.ValorNuloException;

public class Comanda {
	
	private Integer Id_Comanda;
	private Integer numeroComanda;
	private String funcionario;
	private String cliente;
	
	private List<Venda> vendasQueParticipou = new ArrayList<>();
	private List<Produto> produtos = new ArrayList<>();
	
	public Comanda(Integer Id_Comanda, Integer numeroComanda, String funcionario, String cliente) {
		this.Id_Comanda = Id_Comanda;
		this.numeroComanda = numeroComanda;
		this.funcionario = funcionario;
		this.cliente = cliente;
	}
	
	public Integer getId_Comanda() {
		return Id_Comanda;
	}
	
	public void setId_Comanda(Integer Id_Comanda) {
		this.Id_Comanda = Id_Comanda;
	}
		
	public Integer getnumeroComanda() {
		return numeroComanda;
	}
	
	public void setnumeroComanda(Integer numeroComanda) {
		this.numeroComanda = numeroComanda;
	}

	public String getfuncionario() {
		return funcionario;
	}
	
	public void setfuncionario(String funcionario) {
		this.funcionario = funcionario;
	}
	
	public String cliente() {
		return cliente;
	}
	
	public void setcliente(String cliente) {
		this.cliente = cliente;
	}
	
	public List<Produto> getProdutos() {
		return produtos;
	}
	
	public List<Venda> getVendaParticipadas() {
		return vendasQueParticipou;
	}

	public void addProduto(Produto produto) {
		produtos.add(produto);
	}
	
	public void removerProduto(Produto produto) {
		produtos.remove(produto);
	}
	
	public void addVendaParticipada(Venda venda) {
		vendasQueParticipou.add(venda);
	}
	
	public void removerVendaParticipada(Venda venda) {
		vendasQueParticipou.remove(venda);
	}
	
	public void calcularPrecoSubTotal(Venda venda) {
		Double soma = 0.0;
		for (Produto produto : produtos) {
			soma += produto.getPreco();
		}
		if (soma < 0) {
			throw new ValorIlegalException("O preco de algum produto pode estar negativo");
		}
		venda.setpreco_total(soma);
	}
	
	public Double calcularPrecoMedioVendas() {
		Double soma = 0.0;
		for (Venda venda : vendasQueParticipou) {
			if (venda.getValorTotal() == null) {
				throw new ValorNuloException("N�o foi calculado o preco total de todas as vendas ainda.");
			}
			soma += venda.getValorTotal();
		}
		return soma;
	}
	
	public Integer quantidadeProdutos() {
		Integer quantidade = 0;
		
		if (produtos.size() == 0) {
			throw new ValorNuloException("A comanda est� vazia");
		}
		
		quantidade = produtos.size();
		
		return quantidade;
	}
	
	}

