package exceptions;

public class SerasaException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SerasaException(String mensagem) {
		super(mensagem);
	}
}

