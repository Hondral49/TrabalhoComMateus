package exceptions;

public class ValorIlegalException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public ValorIlegalException(String mensagem) {
		super(mensagem);
	}

}
