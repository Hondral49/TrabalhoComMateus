package exceptions;

public class ViaDoClienteException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public ViaDoClienteException(String mensagem) {
		super(mensagem);
	}
	

}
